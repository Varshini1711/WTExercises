<?php
include('db.php');

if (isset($_GET['id'])) {
    $id  = $_GET['id'];
    $sql = "DELETE FROM products WHERE id = $id";

    if (mysqli_query($conn, $sql)) {
        echo "<p style='color:green;'>Product deleted successfully.</p>";
        echo "<a href='products.php'>Back to Products</a>";
    } else {
        echo "<p style='color:red;'>Error: " . mysqli_error($conn) . "</p>";
    }

    mysqli_close($conn);
}
?>
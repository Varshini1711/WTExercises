<!DOCTYPE html>
<html>
<head>
    <title>Products - Fashion Store</title>
    <link rel="stylesheet" href="style.css">
    <style>
        figcaption { color: purple; font-weight: bold; }
    </style>
</head>
<body>

<header>
    <h1>Our Products</h1>
    <nav>
        <a href="index.html">Home</a> |
        <a href="products.php">Products</a> |
        <a href="add_product.php">Add Product</a> |
        <a href="about.html">About</a> |
        <a href="contact.html">Contact</a>
    </nav>
</header>

<hr>

<section>

<!-- Your original static products -->
<h3>Featured Products</h3>

<article style="border:1px solid black; padding:10px;">
    <figure>
        <img src="tshirt.jpg" width="150"
             onmouseover="this.style.border='3px solid red'"
             onmouseout="this.style.border=''">
        <figcaption>T-Shirt</figcaption>
    </figure>
    <p>Price: ₹499</p>
    <button onclick="addToCart('T-Shirt', 499)">Add to Cart</button>
</article>

<br>

<article style="border:1px solid black; padding:10px;">
    <figure>
        <img src="dress.jpg" width="150"
             onmouseover="this.style.border='3px solid red'"
             onmouseout="this.style.border=''">
        <figcaption>Dress</figcaption>
    </figure>
    <p>Price: ₹899</p>
    <button onclick="addToCart('Dress', 899)">Add to Cart</button>
</article>

<p id="cartMsg"></p>
<p id="cartTotal"></p>

<script>
    var total = 0;
    var items = [];
    function addToCart(name, price) {
        total += price;
        items.push(name);
        document.getElementById("cartMsg").innerHTML = "Cart: " + items.join(", ");
        document.getElementById("cartTotal").innerHTML = "Total: ₹" + total;
    }
</script>

<hr>

<!-- Products retrieved from MySQL database -->
<h3>All Products from Database</h3>

<?php
include('db.php');

$sql    = "SELECT * FROM products";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr>
            <th>ID</th>
            <th>Image</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Description</th>
            <th>Action</th>
          </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td><img src='" . $row['image'] . "' width='80' alt='" . $row['name'] . "'></td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['category'] . "</td>";
        echo "<td>&#8377;" . $row['price'] . "</td>";
        echo "<td>" . $row['description'] . "</td>";
        echo "<td><a href='delete_product.php?id=" . $row['id'] . "'>Delete</a></td>";
        echo "</tr>";
    }

    echo "</table>";

} else {
    echo "<p>No products in database yet. <a href='add_product.php'>Add a product</a>.</p>";
}

mysqli_close($conn);
?>

</section>

<footer>
    <p>© 2026 Fashion Store</p>
</footer>

</body>
</html>
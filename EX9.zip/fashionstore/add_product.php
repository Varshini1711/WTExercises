<!DOCTYPE html>
<html>
<head>
    <title>Add Product - Fashion Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Add New Product</h1>
    <nav>
        <a href="index.html">Home</a> |
        <a href="products.php">Products</a> |
        <a href="add_product.php">Add Product</a> |
        <a href="about.html">About</a> |
        <a href="contact.html">Contact</a>
    </nav>
</header>

<hr>

<section>
<h3>Enter Product Details</h3>

<form action="add_product.php" method="post">
    <p>
        <label>Product Name:</label><br>
        <input type="text" name="name" size="30" placeholder="e.g. T-Shirt">
    </p>
    <p>
        <label>Category:</label><br>
        <select name="category">
            <option value="">-- Select Category --</option>
            <option value="Men">Men's Wear</option>
            <option value="Women">Women's Wear</option>
            <option value="Kids">Kids' Wear</option>
        </select>
    </p>
    <p>
        <label>Price (₹):</label><br>
        <input type="number" name="price" size="30" placeholder="e.g. 499">
    </p>
    <p>
        <label>Description:</label><br>
        <textarea name="description" rows="4" cols="40" placeholder="Short product description..."></textarea>
    </p>
    <p>
        <label>Image Filename:</label><br>
        <input type="text" name="image" size="30" placeholder="e.g. tshirt.jpg">
    </p>
    <p>
        <input type="submit" name="submit" value="Add Product">
        <input type="reset" value="Clear">
    </p>
</form>

<?php
if (isset($_POST['submit'])) {

    include('db.php');

    $name        = $_POST['name'];
    $category    = $_POST['category'];
    $price       = $_POST['price'];
    $description = $_POST['description'];
    $image       = $_POST['image'];

    $errors = [];

    if (empty($name))        $errors[] = "Product name is required.";
    if (empty($category))    $errors[] = "Please select a category.";
    if (empty($price))       $errors[] = "Price is required.";
    if (empty($description)) $errors[] = "Description is required.";
    if (empty($image))       $errors[] = "Image filename is required.";

    if (count($errors) > 0) {
        echo "<h3 style='color:red;'>Please fix these errors:</h3><ul>";
        foreach ($errors as $e) {
            echo "<li style='color:red;'>$e</li>";
        }
        echo "</ul>";
    } else {
        $sql = "INSERT INTO products (name, category, price, description, image)
                VALUES ('$name', '$category', '$price', '$description', '$image')";

        if (mysqli_query($conn, $sql)) {
            echo "<h3 style='color:green;'>Product '$name' added successfully!</h3>";
            echo "<p><a href='products.php'>Click here to view all products</a></p>";
        } else {
            echo "<h3 style='color:red;'>Error: " . mysqli_error($conn) . "</h3>";
        }
    }

    mysqli_close($conn);
}
?>

</section>

<footer>
    <p>© 2026 Fashion Store</p>
</footer>

</body>
</html>
<?php
// START SESSION - must be at very top of every page
session_start();

// COOKIE - Check if user visited before
if (isset($_COOKIE['visitor_name'])) {
    $visitorName = $_COOKIE['visitor_name'];
    $returning = true;
} else {
    $visitorName = "";
    $returning = false;
}

// Handle name form submission
if (isset($_POST['save_name'])) {
    $visitorName = $_POST['visitor_name'];
    // SET COOKIE - stores name for 30 days in browser
    setcookie("visitor_name", $visitorName, time() + (30 * 24 * 60 * 60), "/");
    $returning = false;
}

// Handle cart session - clear cart
if (isset($_GET['clear_cart'])) {
    unset($_SESSION['cart']);
    unset($_SESSION['cart_total']);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Fashion Store - Home</title>
    <link rel="stylesheet" href="style.css">
    <style>
        h2 { color: blue; }
    </style>
</head>
<body>

<header>
    <h1>Fashion Store</h1>
    <nav>
        <a href="index.php">Home</a> |
        <a href="products.php">Products</a> |
        <a href="cart.php">Cart
            <?php
            // Show cart count in nav
            if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
                echo "(" . count($_SESSION['cart']) . ")";
            }
            ?>
        </a> |
        <a href="about.html">About</a> |
        <a href="contact.html">Contact</a>
    </nav>
</header>

<hr>

<section>

    <!-- COOKIE: Show welcome message -->
    <?php if ($returning): ?>
        <h3 style="color:green;">
            Welcome back, <?php echo $visitorName; ?>! 
            We missed you at Fashion Store!
        </h3>
    <?php elseif (!empty($visitorName)): ?>
        <h3 style="color:blue;">
            Cookie saved! Welcome, <?php echo $visitorName; ?>!
        </h3>
    <?php endif; ?>

    <!-- Form to save visitor name in cookie -->
    <h3>Enter Your Name</h3>
    <form action="index.php" method="post">
        <p>
            <label>Your Name:</label>
            <input type="text" name="visitor_name" 
                   placeholder="Enter your name" 
                   value="<?php echo $visitorName; ?>">
            <input type="submit" name="save_name" value="Save My Name">
        </p>
    </form>
    <p><small>Your name will be remembered for 30 days using a <b>Cookie</b>.</small></p>

    <hr>

    <h2 style="text-align:center;">Welcome to Fashion Store</h2>
    <p>Your one-stop shop for trendy clothing.</p>

    <p onmouseover="this.style.color='red'"
       onmouseout="this.style.color='black'">
        Hover here to explore our latest collection!
    </p>

    <button onclick="alert('Visit our Products page to start shopping!')">Shop Now</button>

    <hr>

    <!-- SESSION: Show cart summary on home page -->
    <h3>Your Cart Summary</h3>
    <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
        <p>You have <b><?php echo count($_SESSION['cart']); ?></b> item(s) in your cart.</p>
        <p>Total: <b>&#8377;<?php echo $_SESSION['cart_total']; ?></b></p>
        <a href="cart.php">View Cart</a> |
        <a href="index.php?clear_cart=1">Clear Cart</a>
    <?php else: ?>
        <p>Your cart is empty. <a href="products.php">Start Shopping</a></p>
    <?php endif; ?>

</section>

<footer>
    <p>© 2026 Fashion Store</p>
</footer>

</body>
</html>
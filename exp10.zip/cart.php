<?php
// SESSION must start at top
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Cart - Fashion Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Your Shopping Cart</h1>
    <nav>
        <a href="index.php">Home</a> |
        <a href="products.php">Products</a> |
        <a href="cart.php">Cart</a> |
        <a href="about.html">About</a> |
        <a href="contact.html">Contact</a>
    </nav>
</header>

<hr>

<section>

<h3>Items in Your Cart (Stored using SESSION)</h3>

<?php
if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {

    echo "<table border='1' cellpadding='10' cellspacing='0'>";
    echo "<tr><th>Sr. No.</th><th>Product Name</th></tr>";

    foreach ($_SESSION['cart'] as $index => $item) {
        echo "<tr>";
        echo "<td>" . ($index + 1) . "</td>";
        echo "<td>" . $item . "</td>";
        echo "</tr>";
    }

    echo "</table>";
    echo "<p><b>Total Amount: &#8377;" . $_SESSION['cart_total'] . "</b></p>";
    echo "<br>";
    echo "<a href='index.php?clear_cart=1'>Clear Cart</a>";
    echo " | ";
    echo "<a href='products.php'>Continue Shopping</a>";

} else {
    echo "<p>Your cart is empty!</p>";
    echo "<a href='products.php'>Go to Products</a>";
}
?>

<hr>

<!-- COOKIE: Show saved visitor name -->
<h3>Cookie Information</h3>
<?php
if (isset($_COOKIE['visitor_name'])) {
    echo "<p>Shopping as: <b>" . $_COOKIE['visitor_name'] . "</b></p>";
    echo "<p><small>Your name is saved in a Cookie for 30 days.</small></p>";
} else {
    echo "<p>No cookie found. <a href='index.php'>Go to Home</a> to save your name.</p>";
}
?>

</section>

<footer>
    <p>© 2026 Fashion Store</p>
</footer>

</body>
</html>
<?php
session_start();

// Handle Add to Cart using SESSION
if (isset($_POST['add_to_cart'])) {
    $item_name  = $_POST['item_name'];
    $item_price = $_POST['item_price'];

    // Add item to session cart array
    $_SESSION['cart'][]     = $item_name;
    $_SESSION['cart_total'] = isset($_SESSION['cart_total'])
                              ? $_SESSION['cart_total'] + $item_price
                              : $item_price;

    $cartMsg = $item_name . " added to cart!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products - Fashion Store</title>
    <link rel="stylesheet" href="style.css">
    <style>
        figcaption { color: purple; font-weight: bold; }
    </style>
</head>
<body>

<header>
    <h1>Our Products</h1>
    <nav>
        <a href="index.php">Home</a> |
        <a href="products.php">Products</a> |
        <a href="cart.php">Cart
            <?php
            if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
                echo "(" . count($_SESSION['cart']) . ")";
            }
            ?>
        </a> |
        <a href="add_product.php">Add Product</a> |
        <a href="about.html">About</a> |
        <a href="contact.html">Contact</a>
    </nav>
</header>

<hr>

<section>

<!-- Show cart message -->
<?php if (isset($cartMsg)): ?>
    <p style="color:green;"><b><?php echo $cartMsg; ?></b></p>
<?php endif; ?>

<h3>Featured Products</h3>

<!-- Product 1 - T-Shirt -->
<article style="border:1px solid black; padding:10px;">
    <figure>
        <img src="tshirt.jpg" width="150"
             onmouseover="this.style.border='3px solid red'"
             onmouseout="this.style.border=''">
        <figcaption>T-Shirt</figcaption>
    </figure>
    <p>Price: &#8377;499</p>
    <!-- SESSION: Add to cart using form POST -->
    <form action="products.php" method="post">
        <input type="hidden" name="item_name" value="T-Shirt">
        <input type="hidden" name="item_price" value="499">
        <input type="submit" name="add_to_cart" value="Add to Cart">
    </form>
</article>

<br>

<!-- Product 2 - Dress -->
<article style="border:1px solid black; padding:10px;">
    <figure>
        <img src="dress.jpg" width="150"
             onmouseover="this.style.border='3px solid red'"
             onmouseout="this.style.border=''">
        <figcaption>Dress</figcaption>
    </figure>
    <p>Price: &#8377;899</p>
    <form action="products.php" method="post">
        <input type="hidden" name="item_name" value="Dress">
        <input type="hidden" name="item_price" value="899">
        <input type="submit" name="add_to_cart" value="Add to Cart">
    </form>
</article>

<hr>


<footer>
    <p>© 2026 Fashion Store</p>
</footer>

</body>
</html>
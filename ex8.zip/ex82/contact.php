<!DOCTYPE html>
<html>
<head>
    <title>Contact - Fashion Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Contact Us</h1>
    <nav>
        <a href="index.html">Home</a> |
        <a href="products.html">Products</a> |
        <a href="about.html">About</a> |
        <a href="contact.php">Contact</a>
    </nav>
</header>

<section>
    <p>Email: fashionstore@gmail.com</p>
    <p style="color:red;">Phone: 9876543210</p>

    <h3>Contact Form</h3>

    <form action="contact.php" method="post">
        <p>
            <label>Full Name:</label><br>
            <input type="text" name="name" placeholder="Your name" size="30">
        </p>
        <p>
            <label>Email:</label><br>
            <input type="email" name="email" placeholder="Your email" size="30">
        </p>
        <p>
            <label>Phone:</label><br>
            <input type="tel" name="phone" placeholder="10-digit phone number" size="30">
        </p>
        <p>
            <label>Subject:</label><br>
            <select name="subject">
                <option value="">-- Select Subject --</option>
                <option value="order">Order Enquiry</option>
                <option value="return">Return / Refund</option>
                <option value="other">Other</option>
            </select>
        </p>
        <p>
            <label>Message:</label><br>
            <textarea name="message" rows="5" cols="40" placeholder="Type your message..."></textarea>
        </p>
        <p>
            <input type="submit" name="submit" value="Send Message">
            <input type="reset" value="Clear">
        </p>
    </form>

<?php
if (isset($_POST['submit'])) {

    // Collect data
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $phone   = $_POST['phone'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Validate
    $errors = [];

    if (empty($name)) {
        $errors[] = "Name is required.";
    }

    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (empty($phone)) {
        $errors[] = "Phone number is required.";
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $errors[] = "Phone must be exactly 10 digits.";
    }

    if (empty($subject)) {
        $errors[] = "Please select a subject.";
    }

    if (empty($message)) {
        $errors[] = "Message is required.";
    }

    // Display result
    if (count($errors) > 0) {
        echo "<h3 style='color:red;'>Errors:</h3><ul>";
        foreach ($errors as $error) {
            echo "<li style='color:red;'>$error</li>";
        }
        echo "</ul>";
    } else {
        echo "<h3 style='color:green;'>Thank you, $name! Your message has been received.</h3>";
        echo "<p><b>Email:</b> $email</p>";
        echo "<p><b>Phone:</b> $phone</p>";
        echo "<p><b>Subject:</b> $subject</p>";
        echo "<p><b>Message:</b> $message</p>";
    }
}
?>

</section>

<footer>
    <p>© 2026 Fashion Store</p>
</footer>

</body>
</html>